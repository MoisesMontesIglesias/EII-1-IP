
/**
 * Clase destinada a describir personas
 * 
 * @author (Albizu) 
 * @version 13/9/2022
 */
public class Person
{
    
    private String name;
    private int age;
    

    /**
     * Constructor for objects of class Person
     */
    public Person()
    {
        // initialise instance variables
        
    }
    
    public void setName(String newName){
      name=newName;  
    }
    
    public String getName() {
        return name;
    }
    
    public void setAge(int newAge){
      age=newAge;  
    }
    
    public int getAge(){
        return age;
    }
}    