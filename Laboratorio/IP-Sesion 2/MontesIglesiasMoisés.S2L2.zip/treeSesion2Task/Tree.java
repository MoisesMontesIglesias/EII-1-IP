
/**
 * @author (Moisés Montes Iglesias) 
 * Fecha 25/09/2022
 * @version 1.0
 */
public class Tree
{
    public String typeOfTree;//Tipo de árbol
    public int maxNumberOfFlowers;//Número máximo de flores
    public int numberOfFlowers;//Número de flores
    public int numberOfFruits;//Número de frutas

    /**
     * Tipo de árbol con valores ya predefinidos(Manzano, 25, 7, 3)
     */
    public Tree() {//Valores de un árbol ya predefinido, en este caso, un manzano
        setTypeOfTree("Manzano");
        setMaxNumberOfFlowers(25);
        setNumberOfFlowers(7);
        setNumberOfFruits(3);
    }
    
    public Tree(String typeOfTree, int maxNumberOfFlowers, int numberOfFlowers, int numberOfFruits){//Solicitar valores al usuario
        this.typeOfTree = typeOfTree;
        this.maxNumberOfFlowers = maxNumberOfFlowers;
        this.numberOfFlowers = numberOfFlowers;
        this.numberOfFruits = numberOfFruits;
    }
    
    private void setTypeOfTree(String newTypeOfTree){//Le pido al programa que solicite un nombre para el tipo de árbol
        this.typeOfTree = newTypeOfTree;
    }
    
    private String getTypeOfTree() {//Devolver tipo de árbol
        return typeOfTree;
    }
    
    private void checkParam(boolean condition){//Este método lo practicamos en clase y lo utilizo para que en el caso de que el número de valores sea negativo, al utilizar el print salte un error en el programa
        if (condition == false) {
            throw new IllegalArgumentException("La cantidad de flores/frutas no puede ser negativa");
        }
    }
    
    private void setMaxNumberOfFlowers(int newMaxNumberOfFlowers){//Le pido al programa que pida un valor máximo para las flores
        this.maxNumberOfFlowers = newMaxNumberOfFlowers;
    }
    
    private int getMaxNumberOfFlowers(){//Número de flores
        return maxNumberOfFlowers;
    }
    
    private void setNumberOfFlowers(int newNumberOfFlowers){//Le pido al programa que pida un valor para las flores y también que me lo pueda devolver
        checkParam (newNumberOfFlowers >= 0 );
        this.numberOfFlowers = newNumberOfFlowers;
    }
    
    private int getNumberOfFlowers(){
        return numberOfFlowers;
    }
    
    private void setNumberOfFruits(int newNumberOfFruits){//Le pido al programa que pida un valor para las frutas
        checkParam (newNumberOfFruits >= 0 );
        this.numberOfFruits = newNumberOfFruits;
    }
    
    private int getNumberOfFruits(){//Número de frutas
        return numberOfFruits;
    }
    
    public void print(){//Despliegue de una ventana emergente con las siguientes afirmaciones:
        System.out.println("Valores de las propiedades del árbol: " + getTypeOfTree() + "-" + getMaxNumberOfFlowers() + "-" + getNumberOfFlowers() + "-"   + getNumberOfFruits());
    }
    
    public String toString(){//Preciso del método toString para que mediante guiones me de todos los valores dados al programa en una única frase
    if (getNumberOfFlowers() <= maxNumberOfFlowers){
        return getTypeOfTree() + "-" + getMaxNumberOfFlowers() + "-" + getNumberOfFlowers() + "-"   + getNumberOfFruits();
    } 
    if (getNumberOfFlowers() < 0){
            return "Es imposible que tengamos flores negativas";
    }
    return "Es imposible que tengamos más flores que el valor máximo posible";
    }
}
