import java.util.Set;

/**
 * @author Moisés Montes Iglesias
 * Fecha 20/9/2022
 * @version 1.0
 * Clase impartida el martes 20/09/2022 en L-04. Grupo IP.L.2
 */

public class Person
{
    private String name; // Nombre de la persona
    private String surname; // Apellidos de la persona
    private int age; // Edad de la persona en años
    private int getCriticalAge; //Edad de la persona en años
    public boolean gender; // Género de la persona
    
    public final static boolean GENDER_MALE = true;//Género hombre
    public final static boolean GENDER_FEMALE = false;//Género mujer
    
    public final static int MIN_AGE = 0;//Mínimo de edad de una persona
    public final static int MAX_AGE = 120;//Máximo de edad de una persona
    
    public final static int ADULTHOOD_AGE = 18;//Edad para entrar en el intervalo de adulto
    public final static int RETIREMENT_AGE = 65;//Edad en la que se pasa de adulto a jubilado
    /**
     * Crea una persona con valores por defecto de sus atributos (Carlos Sainz, de 27 años y hombre)
     */
    public Person() {
        setSurname("Carlos");
        setName("Sainz");
        setAge(27);
        setGender(GENDER_MALE);
    }
    
    /**
     * Crea una persona con valores por defecto de la edad que te la pide.
     * @param age Edad de la persona en años
     */
    public Person(int age) {
        this();
        setAge(age);
        // setGender(true);
        // setSurname("Alonso");
        // setName("Fernando");
    }
    
    public Person(String name, String surname, int age, boolean gender){
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = GENDER_MALE;
    }
    
    private void setName(String newName){//Pide el nombre
        this.name=newName;  
    }
    
    public String getName() {//Devuelve nombre
        return name;
    }

    private void setSurname(String newSurname){//Pide apellidos
        this.surname = newSurname;
    }
    
    public String getSurname() {//Devuelve apellidos
        return surname; 
    }
    
    private void checkParam(boolean condition){//En caso de una edad negativa
        if (condition == false) {
            throw new IllegalArgumentException("La edad no puede ser negativa");
        }
    }
    
    private void setAge(int newAge){//Prohíbe que la edad sea menor que 0
        checkParam(newAge>=0);
        age = newAge;
    }
    
    /**
     * Obtención de la edad de la persona en años.
     * @return Edad de la persona en años
     */
    public int getAge(){
        return age;
    }
    
    private void setGender(boolean gender){//Pide género
        this.gender = gender;
    }
    
    private boolean getGender(){//Devuelve género
        return gender;
    }
    
    public void print() {//Enseñará uitlizando la función print la edad que tiene y la del año siguiente en una ventana emergente
        System.out.println("Mi edad es "+ getAge() + " pero el año que viene tendre " + (getAge() + 1) + " años.");
    }
    
    public String toString(){//Enseñará el nombre, apellidos, edad y género separado por guiones
        // if (getGender() == true) {
            // return getName() + "-" + getSurname() + "-" + getAge() + "-masculino";
        // }
        // else {
            // return getName() + "-" + getSurname() + "-" + getAge() + "-femenino";
        // }
        // if (getGender() == true) {
            // return getName() + "-" + getSurname() + "-" + getAge() + "-masculino";
        // if (getGender() == false) {
            // return getName() + "-" + getSurname() + "-" + getAge() + "-femenino";
        // }
        // return "No sé";
        // }
        // String tmp;
        
        // tmp = getName() + "-" + getSurname() + "-" + getAge() + "-";
        // if (getGender()==GENDER_MALE) {
            // tmp=tmp+"masculino";
        // }
        // else {
            // tmp=tmp + "-femenino";
        // }
        // return tmp;
    
        return getName() + "-" + getSurname() +"-"+ getAge() +"-"+ (getGender()?"masculino":"femenino");
    }
    
    public String getCriticalAge (){//Mostrará al usuario su nombre, la edad que tiene y los años que le faltan para el siguiente rango de edad o el tiempo que lleva jubilado
        if (getAge() < ADULTHOOD_AGE) {//Este código se mostrará a la persona que haya rellenado los datos al crear el objeto y tenga menos de 18 años
        return getName() + " tienes " + getAge() + " año/s, y te faltan " + (18 - getAge() + " año/s para cumplir los 18 años.");
        }
        if (getAge() > RETIREMENT_AGE) {//Este código se mostrará a la persona que haya rellenado los datos al crear el objeto y tenga más de 65, e indicará también cuantos años lleva jubilado/a
        return getName() + " tienes " + getAge() + " año/s, y llevas" + (getAge() - 65 + "año/s jubilado.");
        }//Este código se mostrará a la persona que haya rellenado los datos al crear el objeto y tenga entre 18 y 65 años
        return getName() + " tienes " + getAge() + " año/s, y te faltan " + (65 - getAge() + " año/s para cumplir los 65 años.");
    }    
}