
/**
 * Tarea realizada en clase
 * 
 * Moisés Montes Iglesias
 * 13/9/2022
 */
public class Person
{
    
    private String name;
    private int age;
    

    public void setName(String newName){
      name=newName;  
    }
    
    public String getName() {
        return name;
    }
    
    public void setAge(int newAge){
      age=newAge;  
    }
    
    public int getAge(){
        return age;
    }
}    