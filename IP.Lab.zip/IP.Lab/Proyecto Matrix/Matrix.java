import java.util.*;

/**
 * Write a description of class Matrix here.
 * 
 * @author Moisés Montes Iglesias 
 * @version 16-12-2022
 */
public class Matrix
{
    /**
     * Constante del valor mínimo que se debe dar de número enteros
     */
    public static final int MIN_NUM = 0;
    
    /**
     * Constante del valor máximo que se puede dar de número enteros
     */
    public static final int MAX_NUM = 255;
    
    /**
     * Constante del valor mínimo de la dimensión de la matriz
     */
    public static final int MIN_DIM = 2;
    
    /**
     * Constante del valor máximo de la dimensión de la matriz
     */
    public static final int MAX_DIM = 20;
    
    private int [][] matrix;
    /**
     * Constructor con parámetro dimension que muestra por pantalla una matriz
     * de números aleatorios con una dimensión que se define por un parámetro
     * solicitado
     * 
     * @param dimension, dimension que tiene la matriz
     */
    public Matrix(int dimension)
    {
        checkParam(dimension >= MIN_DIM && dimension <= MAX_DIM, "Invalid dimension for the matrix");
        Random random = new Random();
        matrix = new int[dimension][dimension];
        for(int i = 0; i <matrix.length; i++){
            for (int j = 0; j<matrix[0].length; j++){
                matrix[i][j] = random.nextInt(MAX_NUM + 1);
            }
        }
    }
    
    /**
     * Constructor con parámetro array
     * Recibe una copia de la matriz pasada como parámetro
     * 
     * @param int[][]matrix, valores de la matriz
     */
    public Matrix(int [][] matrix){
        checkParam(matrix.length>=2 && matrix.length <= 20, "Invalid dimension for the matrix");
        checkParam(matrix.length == matrix[0].length, "The matrix must be square");
        this.matrix = matrix;
    }
    
    /**
     * Método getMatrix que devuelve una copia de la matriz creada
     */
    public int [][] getMatrix(){
        int [][] matrixCopy = new int [matrix.length][matrix[0].length];
        for (int i = 0; i<matrix.length; i++){
            for(int j = 0; j<matrix[0].length; j++){
                matrixCopy[i][j] = matrix[i][j];
            }
        }
        return matrixCopy;
    }
    
    /**
     * Método flattenMatrix, devuelve el contenido de la matriz en un ArrayList
     */
    public ArrayList<Integer> flattenMatrix(){
        int[][] matrix1= getMatrix();
        ArrayList<Integer> lista = new ArrayList<Integer>();
        for(int i = 0; i<matrix1.length; i++){
            for(int j = 0; j<matrix1[0].length; j++){
                lista.add(matrix1[i][j]);
            }
        }
        System.out.print(lista);
        return lista;
    }
    
    /**
     * Método swapReverseByDiagonals, intercambia los elementos de las dos diagonales, invirtiendo
     * sus elementos.
     */
    public void swapReverseByDiagonals(){
        for(int i = 0; i<matrix.length; i++){
            int a = matrix[matrix.length-1-i][i];
            matrix[matrix.length-1-i][i] = matrix[i][i]; //x30 = x00...
            matrix[i][i] = a; //x00 = x30...
        }
    }
    
    /**
     * Método moveColumn, mueve los elementos de la columna que se pasa como parámetro al final de
     * la matriz, desplazando el resto de columnas a la izquierda.
     * @param column, columna que se desea desplazar al final de la matriz
     */
    public void moveColumn(int column){
        checkParam(column >= 0 && column <= matrix.length, "Column value is incorrect"); 
        for(int i = 0; i<matrix.length; i++){
            int a = matrix[i][column];
            for(int j = 0; j<matrix[0].length; j++){
                if(column+j<matrix[0].length-1){
                    int b = matrix[i][column+j+1];
                    matrix[i][column + j] = matrix[i][column + j + 1];
                }
            }
            matrix[i][matrix[0].length-1] = a;
        }
    }
    
    /**
     * Método print, que muestra por consola el contenido de la matriz
     */
    public void print(){
        for (int i = 0; i<matrix.length; i++){
            for(int j = 0; j<matrix[i].length; j++){
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }
    
    private void checkParam(boolean condition, String msg){
        if(!condition){
            throw new IllegalArgumentException(msg);
        }
    }
}
