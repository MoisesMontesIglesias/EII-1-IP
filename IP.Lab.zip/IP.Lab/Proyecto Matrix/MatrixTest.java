

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.*;

/**
 * The test class MatrixTest.
 *
 * @author  Moisés Montes Iglesias
 * @version 16-12-2022
 */
public class MatrixTest
{
    /**
     * Casos para el constructor con el parámetro array
     * Casos de uso:
     * Casos positivos:
     * Caso 1: Matriz cuadrada
     * Caso 2: Matriz cuadrada con dimensión mínima
     * Caso 3: Matriz cuadrada con dimensión máxima
     * 
     * Casos negativos:
     * Caso 4: Matriz no cuadrada
     * Caso 5: Matriz muy pequeña
     * Caso 6: Matriz muy grande
     */
     
    /**
     * Caso 1: Matriz cuadrada
     */
    @Test
    public void constructorCorrect(){
        int[][]m = {{1,2,3},{4,5,6},{7,8,9}};
        Matrix matrix = new Matrix(m);
        assertEquals(3,matrix.getMatrix().length);
        assertEquals(3,matrix.getMatrix()[0].length);
    }
    
    /**
     * Caso 2: Matriz cuadrada con dimensión mínima
     */
    @Test
    public void constructorCorrectMínDim(){
        int[][]m = {{1,2},{3,4}};
        Matrix matrix = new Matrix(m);
        assertEquals(2,matrix.getMatrix().length);
        assertEquals(2,matrix.getMatrix()[0].length);
    }
    
    /**
     * Caso 3: Matriz cuadrada con dimensión máxima
     */
    @Test
    public void constructorCorrectMáxDim(){
        int[][]m = {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
        Matrix matrix = new Matrix(m);
        assertEquals(20,matrix.getMatrix().length);
        assertEquals(20,matrix.getMatrix()[0].length);
    }
    
    /**
     * Caso 4: Matriz no cuadrada
     */
    @Test
    public void constructorNoSquare(){
        int[][]m = {{1,2},{3,4},{5,6}};
        try{
            Matrix matrix = new Matrix(m);
            fail("Debería haber fallado porque la dimensión es incorrecto");
        } catch (RuntimeException e){
            assertEquals("The matrix must be square", e.getMessage());
        }
    }
    
    /**
     * Caso 5: Matriz muy pequeña
     */
    @Test
    public void constructorSmallerThanMin(){
        int[][]m = {{1}};
        try{
            Matrix matrix = new Matrix(m);
            fail("Debería haber fallado porque la dimensión de la matriz es incorrecta");
        } catch (RuntimeException e){
            assertEquals("Invalid dimension for the matrix", e.getMessage());
        }
    }
    
    /**
     * Caso 6: Matriz muy grande
     */
    @Test
    public void constructorBiggerThanMax(){
        int[][]m = {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
        try{
            Matrix matrix = new Matrix(m);
            fail("Debería haber fallado porque la dimensión de la matriz es incorrecta");
        } catch (RuntimeException e){
            assertEquals("Invalid dimension for the matrix", e.getMessage());
        }
    }
    
    /**
     * Pruebas del método flattenMatrix
     * Casos positivos:
     * Caso 1: La matriz cuadrada se pasa a forma arrayList
     * 
     * Casos incompletos:
     * Caso 2: La matriz no guarda suficientes números
     * Caso 3: La matriz guarda demasiados números
     */
    
    /**
     * Prueba del método flattenMatrix
     * Caso 1: La matriz cuadrada se pasa a forma arrayList
     */
    @Test 
    public void flattenMatrixUniqueCase(){
        int[][]m = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        Matrix matrix = new Matrix(m);
        ArrayList<Integer> lista = new ArrayList<Integer>();
        lista.add(1); lista.add(2); lista.add(3); lista.add(4); lista.add(5); lista.add(6); lista.add(7); lista.add(8);
        lista.add(9); lista.add(10); lista.add(11); lista.add(12); lista.add(13); lista.add(14); lista.add(15); lista.add(16);
        matrix.flattenMatrix().equals(lista);
    }
    
    /**
     * Prueba del método flattenMatrix
     * Caso 2: La matriz no guarda suficientes números
     */
    @Test 
    public void flattenMatrixNotEnough(){
        int[][]m = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        Matrix matrix = new Matrix(m);
        ArrayList<Integer> lista = new ArrayList<Integer>();
        lista.add(1); lista.add(2); lista.add(3); lista.add(4); lista.add(5); lista.add(6);
        matrix.flattenMatrix().equals(lista);
    }
    
    /**
     * Prueba del método flattenMatrix
     * Caso 3: La matriz guarda demasiados números
     */
    @Test 
    public void flattenMatrixTooMuch(){
        int[][]m = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        Matrix matrix = new Matrix(m);
        ArrayList<Integer> lista = new ArrayList<Integer>();
        lista.add(1); lista.add(2); lista.add(3); lista.add(4); lista.add(5); lista.add(6); lista.add(7); lista.add(8);
        lista.add(9); lista.add(10); lista.add(11); lista.add(12); lista.add(13); lista.add(14); lista.add(15); lista.add(16);
        lista.add(17); lista.add(18); lista.add(19); lista.add(20); lista.add(21); lista.add(22); lista.add(23); lista.add(24);
        matrix.flattenMatrix().equals(lista);
    }
    
    /**
     * Pruebas del método swapReverseByDiagonals
     * Casos positivos:
     * Caso 1: La matriz intercambia sus diagonales correctamente
     * Caso 2: La matriz(pequeña) intercambia sus diagonales correctamente
     * Caso 3: La matriz(grande) intercambia sus diagonales correctamente
     */
    
    /**
     * Prueba del método swapReverseByDiagonals
     * Caso 1: La matriz intercambia sus diagonales correctamente
     */
    @Test 
    public void swapReverseByDiagonalsCorrect(){
        int[][]m = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        Matrix matrix = new Matrix(m);
        matrix.swapReverseByDiagonals();
        int[][]n = {{13,2,3,16},{5,10,11,8},{9,6,7,12},{1,14,15,4}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * Caso 2: La matriz(pequeña) intercambia sus diagonales correctamente
     */
    @Test 
    public void swapReverseByDiagonalsShort(){
        int[][]m = {{1,2,3},{4,5,6},{7,8,9}};
        Matrix matrix = new Matrix(m);
        matrix.swapReverseByDiagonals();
        int[][]n = {{7,2,9},{4,5,6},{1,8,3}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * Caso 3: La matriz(grande) intercambia sus diagonales correctamente
     */
    @Test 
    public void swapReverseByDiagonalsLong(){
        int[][]m = {{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},
        {19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};
        Matrix matrix = new Matrix(m);
        matrix.swapReverseByDiagonals();
        int[][]n = {{31,2,3,4,5,36},{7,26,9,10,29,12},{13,14,21,22,17,18},
        {19,20,15,16,23,24},{25,8,27,28,11,30},{1,32,33,34,35,6}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Pruebas del método moveColumn
     * Casos positivos:
     * Caso 1: La matriz intercambia sus columnas correctamente según el valor del parámetro dado
     * Caso 2: El valor del parámetro column, es mínimo
     * Caso 3: El valor del parámetro column, que realiza el cambio, es máximo
     * 
     * Caso irrelevante:
     * Caso 4: El valor del parámetro column es máximo
     * 
     * Casos negativos:
     * Caso 5: El valor del parámetro column, es excesivo
     * Caso 6: El valor del parámetro column, es negativo
     */
    
    /**
     * Prueba del método swapReverseByDiagonals
     * Caso 1: La matriz intercambia sus diagonales correctamente
     */
    @Test 
    public void moveColumnCorrect(){
        int[][]m = {{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},
        {19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};
        Matrix matrix = new Matrix(m);
        matrix.moveColumn(3);
        int[][]n = {{1,2,3,5,6,4},{7,8,9,11,12,10},{13,14,15,17,18,16},
        {19,20,21,23,24,22},{25,26,27,29,30,28},{31,32,33,35,36,34}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * La matriz intercambia sus diagonales correctamente
     * Caso 2: El valor del parámetro column, es mínimo
     */
    @Test 
    public void moveColumnCorrectShort(){
        int[][]m = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        Matrix matrix = new Matrix(m);
        matrix.moveColumn(0);
        int[][]n = {{2,3,4,1},{6,7,8,5},{10,11,12,9},{14,15,16,13}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * La matriz intercambia sus diagonales correctamente
     * Caso 3: El valor del parámetro column, que realiza un cambio, es máximo
     */
    @Test 
    public void moveColumnCorrectLong(){
        int[][]m = {{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20},{21,22,23,24,25}};
        Matrix matrix = new Matrix(m);
        matrix.moveColumn(3);
        int[][]n = {{1,2,3,5,4},{6,7,8,10,9},{11,12,13,15,14},{16,17,18,20,19},{21,22,23,25,24}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * La matriz intercambia sus diagonales correctamente
     * Caso 4: El valor del parámetro column es máximo
     */
    @Test 
    public void moveColumnCorrectLongest(){
        int[][]m = {{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},
        {19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};
        Matrix matrix = new Matrix(m);
        matrix.moveColumn(5);
        int[][]n = {{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},
        {19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};
        assertArrayEquals(m,n);
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * La matriz no intercambia sus diagonales
     * Caso 5: El valor del parámetro column es excesivo
     */
    @Test 
    public void moveColumnIncorrectTooMuch(){
        int[][]m = {{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},
        {19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};
        try{
            Matrix matrix = new Matrix(m);
            matrix.moveColumn(8);
            fail("Debería haber fallado porque el valor del parámetro column es negativo");
        }catch(RuntimeException e){
            assertEquals("Column value is incorrect", e.getMessage());
        }
    }
    
    /**
     * Prueba del método swapReverseByDiagonals
     * La matriz no intercambia sus diagonales
     * Caso 6: El valor del parámetro column es negativo
     */
    @Test 
    public void moveColumnIncorrectNegative(){
        int[][]m = {{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},
        {19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};
        try{
            Matrix matrix = new Matrix(m);
            matrix.moveColumn(-1);
            fail("Debería haber fallado porque el valor del parámetro column es negativo");
        }catch(RuntimeException e){
            assertEquals("Column value is incorrect", e.getMessage());
        }
    }
}
